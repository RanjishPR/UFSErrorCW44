sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";const e=n.extend("ns.manager.controller.App",{onInit:function n(){}});return e});
//# sourceMappingURL=App.controller.js.map