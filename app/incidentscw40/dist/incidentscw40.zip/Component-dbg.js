sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ns.incidentscw40.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);